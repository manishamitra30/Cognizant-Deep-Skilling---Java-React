package com.example.oauth2_login_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Oauth2LoginServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(Oauth2LoginServiceApplication.class, args);
    }
}