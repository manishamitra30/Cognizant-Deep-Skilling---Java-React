import org.junit.platform.suite.api.SelectClasses;
import org.junit.platform.suite.api.Suite;
import org.junit.runner.manipulation.Orderer;

@Suite
@SelectClasses({
    EvenCheckerTest.class,
    Orderer.class
})
public class AllTests {
}