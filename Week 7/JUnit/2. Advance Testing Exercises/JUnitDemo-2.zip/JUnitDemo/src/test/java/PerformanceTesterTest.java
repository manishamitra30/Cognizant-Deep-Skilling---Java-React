import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.time.Duration;

public class PerformanceTesterTest {

    @Test
    void testTimeout() {
        PerformanceTester tester = new PerformanceTester();

        assertTimeout(Duration.ofSeconds(3), () -> {
            tester.performTask();
        });
    }
}