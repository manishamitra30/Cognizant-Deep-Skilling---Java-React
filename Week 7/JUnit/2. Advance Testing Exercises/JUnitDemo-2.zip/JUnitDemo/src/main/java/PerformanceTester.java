public class PerformanceTester {

    public void performTask() throws InterruptedException {
        Thread.sleep(2000); // 2 seconds
    }
}