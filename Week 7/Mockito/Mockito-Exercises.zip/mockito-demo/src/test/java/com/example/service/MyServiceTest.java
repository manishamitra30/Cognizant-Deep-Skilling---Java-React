package com.example.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.Test;

import com.example.api.ExternalApi;

public class MyServiceTest {

    // ✅ Exercise 1: Mocking and Stubbing
    @Test
    public void testMockingAndStubbing() {
        ExternalApi mockApi = mock(ExternalApi.class);

        when(mockApi.getData()).thenReturn("Mock Data");

        MyService service = new MyService(mockApi);

        String result = service.fetchData();

        assertEquals("Mock Data", result);
    }

    // ✅ Exercise 2: Verifying Interaction
    @Test
    public void testVerifyInteraction() {
        ExternalApi mockApi = mock(ExternalApi.class);

        MyService service = new MyService(mockApi);
        service.fetchData();

        verify(mockApi).getData();
    }

    // ✅ Exercise 3: Argument Matching
    @Test
    public void testArgumentMatching() {
        ExternalApi mockApi = mock(ExternalApi.class);

        when(mockApi.getDataById(anyInt())).thenReturn("Matched Data");

        MyService service = new MyService(mockApi);

        String result = service.fetchDataById(10);

        assertEquals("Matched Data", result);

        verify(mockApi).getDataById(anyInt());
    }

    // ✅ Exercise 4: Handling Void Methods
    @Test
    public void testVoidMethod() {
        ExternalApi mockApi = mock(ExternalApi.class);

        doNothing().when(mockApi).sendData("Test");

        MyService service = new MyService(mockApi);
        service.sendData("Test");

        verify(mockApi).sendData("Test");
    }

    // ✅ Exercise 5: Multiple Returns
    @Test
    public void testMultipleReturns() {
        ExternalApi mockApi = mock(ExternalApi.class);

        when(mockApi.getData())
                .thenReturn("First")
                .thenReturn("Second");

        MyService service = new MyService(mockApi);

        String first = service.fetchData();
        String second = service.fetchData();

        assertEquals("First", first);
        assertEquals("Second", second);
    }

    

    // ✅ Exercise 7: Void Method with Exception
    @Test
    public void testVoidException() {
        ExternalApi mockApi = mock(ExternalApi.class);

        doThrow(new RuntimeException("Error"))
                .when(mockApi).sendData("Fail");

        MyService service = new MyService(mockApi);

        assertThrows(RuntimeException.class, () -> {
            service.sendData("Fail");
        });

        verify(mockApi).sendData("Fail");
    }
}