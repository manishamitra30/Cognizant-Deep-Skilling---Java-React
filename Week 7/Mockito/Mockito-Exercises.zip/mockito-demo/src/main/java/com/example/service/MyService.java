package com.example.service;

import com.example.api.ExternalApi;

public class MyService {

    private ExternalApi api;

    // Constructor Injection
    public MyService(ExternalApi api) {
        this.api = api;
    }

    // Exercise 1 & 5
    public String fetchData() {
        return api.getData();
    }

    // Exercise 3
    public String fetchDataById(int id) {
        return api.getDataById(id);
    }

    // Exercise 4 & 7
    public void sendData(String data) {
        api.sendData(data);
    }

    // Exercise 6 (IMPORTANT - your failing test depends on this)
    public void processData() {
        String data = api.getData();  // Step 1
        api.sendData(data);           // Step 2 (must be AFTER getData)
    }
}