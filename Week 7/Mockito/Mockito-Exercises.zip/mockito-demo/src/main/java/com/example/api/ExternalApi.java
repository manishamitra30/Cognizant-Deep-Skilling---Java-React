package com.example.api;

public interface ExternalApi {
    String getData();
    String getDataById(int id);
    void sendData(String data);
}