package com.example.service;

import com.example.api.RestClient;

public class ApiService {

    private RestClient client;

    public ApiService(RestClient client) {
        this.client = client;
    }

    public String fetchData() {
        return "Fetched " + client.getResponse();
    }
}