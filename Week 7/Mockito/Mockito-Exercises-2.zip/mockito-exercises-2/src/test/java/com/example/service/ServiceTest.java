package com.example.service;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import org.junit.jupiter.api.Test;

import com.example.repository.Repository;

public class ServiceTest {

    @Test
    public void testServiceWithMockRepository() {
        Repository mockRepo = mock(Repository.class);

        when(mockRepo.getData()).thenReturn("Mock Data");

        Service service = new Service(mockRepo);

        assertEquals("Processed Mock Data", service.processData());
    }
}