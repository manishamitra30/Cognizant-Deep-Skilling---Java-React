package com.example.service;

import com.example.api.RestClient;
import org.junit.jupiter.api.Test;

import static org.mockito.Mockito.*;
import static org.junit.jupiter.api.Assertions.*;

public class ApiServiceTest {

    @Test
    public void testServiceWithMockRestClient() {
        RestClient mockClient = mock(RestClient.class);

        when(mockClient.getResponse()).thenReturn("Mock Response");

        ApiService service = new ApiService(mockClient);

        assertEquals("Fetched Mock Response", service.fetchData());
    }
}