package proxypattern;

public class TestProxyPattern {
    public static void main(String[] args) {
        Image image1 = new ProxyImage("photo1.jpg");

        System.out.println("First call:");
        image1.display();

        System.out.println();

        System.out.println("Second call:");
        image1.display();
    }
}
