package strategypattern;

public class TestStrategyPattern {
    public static void main(String[] args) {
        PaymentContext context = new PaymentContext(
                new CreditCardPayment("1234-5678-9012", "Arun Kumar"));
        context.executePayment(5000.00);

        System.out.println();

        context.setPaymentStrategy(new PayPalPayment("arun@example.com"));
        context.executePayment(2500.50);
    }
}
