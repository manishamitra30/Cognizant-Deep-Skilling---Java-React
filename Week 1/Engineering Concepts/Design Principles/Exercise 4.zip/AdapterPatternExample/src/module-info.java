module AdapterPatternExample {
}