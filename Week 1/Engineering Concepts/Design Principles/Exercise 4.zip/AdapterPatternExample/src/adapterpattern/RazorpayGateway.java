package adapterpattern;

public class RazorpayGateway {
    public void payAmount(double amount) {
        System.out.println("Payment of Rs." + amount + " processed through Razorpay.");
    }
}
