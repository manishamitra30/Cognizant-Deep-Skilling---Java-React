package adapterpattern;

public class StripeGateway {
    public void makeCharge(double amount) {
        System.out.println("Payment of Rs." + amount + " processed through Stripe.");
    }
}
