package adapterpattern;

public class TestAdapterPattern {
    public static void main(String[] args) {
        PaymentProcessor paypal = new PayPalAdapter(new PayPalGateway());
        PaymentProcessor stripe = new StripeAdapter(new StripeGateway());
        PaymentProcessor razorpay = new RazorpayAdapter(new RazorpayGateway());

        paypal.processPayment(2500.00);
        stripe.processPayment(4200.50);
        razorpay.processPayment(1999.99);
    }
}
