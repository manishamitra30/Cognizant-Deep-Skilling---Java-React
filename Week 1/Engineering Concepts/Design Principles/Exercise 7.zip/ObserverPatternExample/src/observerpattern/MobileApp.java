package observerpattern;

public class MobileApp implements Observer {
    private String userName;

    public MobileApp(String userName) {
        this.userName = userName;
    }

    public void update(String stockName, double stockPrice) {
        System.out.println("Mobile App Notification for " + userName +
                ": " + stockName + " price changed to " + stockPrice);
    }
}
