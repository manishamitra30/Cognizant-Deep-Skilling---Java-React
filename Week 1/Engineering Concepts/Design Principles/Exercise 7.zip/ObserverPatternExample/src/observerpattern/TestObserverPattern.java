package observerpattern;

public class TestObserverPattern {
    public static void main(String[] args) {
        StockMarket stockMarket = new StockMarket("TCS", 3500.00);

        Observer mobileUser = new MobileApp("Arun");
        Observer webUser = new WebApp("Divya");

        stockMarket.registerObserver(mobileUser);
        stockMarket.registerObserver(webUser);

        stockMarket.setStockPrice(3550.75);
        stockMarket.setStockPrice(3600.50);

        stockMarket.deregisterObserver(webUser);

        stockMarket.setStockPrice(3655.25);
    }
}
