package observerpattern;

public class WebApp implements Observer {
    private String userName;

    public WebApp(String userName) {
        this.userName = userName;
    }

    public void update(String stockName, double stockPrice) {
        System.out.println("Web App Notification for " + userName +
                ": " + stockName + " price changed to " + stockPrice);
    }
}
