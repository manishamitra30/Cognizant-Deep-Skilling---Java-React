module DecoratorPatternExample {
}