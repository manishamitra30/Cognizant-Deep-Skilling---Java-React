package singletonpattern;

public class Logger {

    // private static instance
    private static Logger instance;

    // private constructor
    private Logger() {
        System.out.println("Logger instance created.");
    }

    // public static method to return the same instance
    public static Logger getInstance() {
        if (instance == null) {
            instance = new Logger();
        }
        return instance;
    }

    // logging method
    public void log(String message) {
        System.out.println("Log: " + message);
    }
}
