module SingletonPatternExample {
}