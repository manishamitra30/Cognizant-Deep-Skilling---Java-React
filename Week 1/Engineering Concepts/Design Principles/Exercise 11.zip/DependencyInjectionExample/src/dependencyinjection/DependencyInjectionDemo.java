package dependencyinjection;

public class DependencyInjectionDemo {
    public static void main(String[] args) {
        CustomerRepository repository = new CustomerRepositoryImpl();
        CustomerService service = new CustomerService(repository);

        System.out.println(service.getCustomerById(101));
        System.out.println(service.getCustomerById(102));
        System.out.println(service.getCustomerById(103));
    }
}
