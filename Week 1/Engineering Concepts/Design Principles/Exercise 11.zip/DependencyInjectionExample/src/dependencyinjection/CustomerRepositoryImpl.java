package dependencyinjection;

public class CustomerRepositoryImpl implements CustomerRepository {
    public String findCustomerById(int id) {
        if (id == 101) {
            return "Customer Found: Arun Kumar";
        } else if (id == 102) {
            return "Customer Found: Divya Sharma";
        } else {
            return "Customer not found";
        }
    }
}
