package builderpattern;

public class TestBuilderPattern {
    public static void main(String[] args) {
        Computer gamingComputer = new Computer.Builder()
                .setCpu("Intel Core i9")
                .setRam("32GB")
                .setStorage("1TB SSD")
                .setGraphicsCard("NVIDIA RTX 4080")
                .setOperatingSystem("Windows 11")
                .build();

        Computer officeComputer = new Computer.Builder()
                .setCpu("Intel Core i5")
                .setRam("16GB")
                .setStorage("512GB SSD")
                .setOperatingSystem("Windows 10")
                .build();

        System.out.println("Gaming Computer:");
        gamingComputer.showConfiguration();

        System.out.println();

        System.out.println("Office Computer:");
        officeComputer.showConfiguration();
    }
}
