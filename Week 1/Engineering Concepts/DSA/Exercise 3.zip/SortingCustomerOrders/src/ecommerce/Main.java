package ecommerce;

public class Main {
    public static void main(String[] args) {

        Order[] orders1 = {
            new Order(1, "Amit", 2500.50),
            new Order(2, "Sneha", 5200.00),
            new Order(3, "Rahul", 1800.75),
            new Order(4, "Priya", 7600.20),
            new Order(5, "Karan", 4300.10)
        };

        Order[] orders2 = {
            new Order(1, "Amit", 2500.50),
            new Order(2, "Sneha", 5200.00),
            new Order(3, "Rahul", 1800.75),
            new Order(4, "Priya", 7600.20),
            new Order(5, "Karan", 4300.10)
        };

        System.out.println("Before Bubble Sort:");
        SortOrders.displayOrders(orders1);

        SortOrders.bubbleSort(orders1);
        System.out.println("\nAfter Bubble Sort (Descending by Total Price):");
        SortOrders.displayOrders(orders1);

        System.out.println("\nBefore Quick Sort:");
        SortOrders.displayOrders(orders2);

        SortOrders.quickSort(orders2, 0, orders2.length - 1);
        System.out.println("\nAfter Quick Sort (Descending by Total Price):");
        SortOrders.displayOrders(orders2);
    }
}
