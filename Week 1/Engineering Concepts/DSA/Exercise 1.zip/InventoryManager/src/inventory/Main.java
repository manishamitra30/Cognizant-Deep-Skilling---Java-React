package inventory;

public class Main {
    public static void main(String[] args) {
        InventoryManager manager = new InventoryManager();

        Product p1 = new Product(101, "Keyboard", 50, 799.99);
        Product p2 = new Product(102, "Mouse", 80, 499.50);

        manager.addProduct(p1);
        manager.addProduct(p2);

        manager.displayProducts();
    }
}
