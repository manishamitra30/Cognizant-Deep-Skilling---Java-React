module InventoryManager {
}