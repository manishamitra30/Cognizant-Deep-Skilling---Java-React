package ecommerce;

public class Main {
    public static void main(String[] args) {

        Product[] products = {
            new Product(105, "Laptop", "Electronics"),
            new Product(101, "Shoes", "Fashion"),
            new Product(103, "Watch", "Accessories"),
            new Product(102, "Phone", "Electronics"),
            new Product(104, "Bag", "Fashion")
        };

        // For binary search, array must be sorted by productId
        Product[] sortedProducts = {
            new Product(101, "Shoes", "Fashion"),
            new Product(102, "Phone", "Electronics"),
            new Product(103, "Watch", "Accessories"),
            new Product(104, "Bag", "Fashion"),
            new Product(105, "Laptop", "Electronics")
        };

        int targetId = 103;

        Product linearResult = Search.linearSearch(products, targetId);
        if (linearResult != null) {
            System.out.println("Linear Search Found: " + linearResult);
        } else {
            System.out.println("Product not found using Linear Search.");
        }

        Product binaryResult = Search.binarySearch(sortedProducts, targetId);
        if (binaryResult != null) {
            System.out.println("Binary Search Found: " + binaryResult);
        } else {
            System.out.println("Product not found using Binary Search.");
        }
    }
}
