package librarymanagement;

public class Main {
    public static void main(String[] args) {

        Book[] books = {
            new Book(101, "Java Basics", "James Gosling"),
            new Book(102, "Data Structures", "Mark Allen"),
            new Book(103, "Operating Systems", "Andrew Tanenbaum"),
            new Book(104, "Computer Networks", "Forouzan")
        };

        // Sorted array by title for binary search
        Book[] sortedBooks = {
            new Book(104, "Computer Networks", "Forouzan"),
            new Book(102, "Data Structures", "Mark Allen"),
            new Book(101, "Java Basics", "James Gosling"),
            new Book(103, "Operating Systems", "Andrew Tanenbaum")
        };

        String targetTitle = "Java Basics";

        Book linearResult = LibrarySearch.linearSearch(books, targetTitle);
        if (linearResult != null) {
            System.out.println("Linear Search Found: " + linearResult);
        } else {
            System.out.println("Book not found using Linear Search.");
        }

        Book binaryResult = LibrarySearch.binarySearch(sortedBooks, targetTitle);
        if (binaryResult != null) {
            System.out.println("Binary Search Found: " + binaryResult);
        } else {
            System.out.println("Book not found using Binary Search.");
        }
    }
}
