package employee;

public class Main {
    public static void main(String[] args) {
        EmployeeManagement management = new EmployeeManagement(5);

        management.addEmployee(new Employee(101, "Arun", "Manager", 75000));
        management.addEmployee(new Employee(102, "Divya", "Developer", 60000));
        management.addEmployee(new Employee(103, "Kiran", "Tester", 50000));

        System.out.println("\nAll Employees:");
        management.traverseEmployees();

        System.out.println("\nSearching for employee with ID 102:");
        Employee found = management.searchEmployee(102);
        if (found != null) {
            System.out.println(found);
        } else {
            System.out.println("Employee not found.");
        }

        System.out.println("\nDeleting employee with ID 101:");
        management.deleteEmployee(101);

        System.out.println("\nEmployees after deletion:");
        management.traverseEmployees();
    }
}
