package taskmanagement;

public class Main {
    public static void main(String[] args) {
        TaskManagement taskList = new TaskManagement();

        taskList.addTask(new Task(1, "Design Homepage", "Pending"));
        taskList.addTask(new Task(2, "Develop Login Module", "In Progress"));
        taskList.addTask(new Task(3, "Test Payment Gateway", "Completed"));

        System.out.println("All Tasks:");
        taskList.traverseTasks();

        System.out.println("\nSearching for Task ID 2:");
        Task found = taskList.searchTask(2);
        if (found != null) {
            System.out.println(found);
        } else {
            System.out.println("Task not found.");
        }

        System.out.println("\nDeleting Task ID 1:");
        taskList.deleteTask(1);

        System.out.println("\nTasks after deletion:");
        taskList.traverseTasks();
    }
}
