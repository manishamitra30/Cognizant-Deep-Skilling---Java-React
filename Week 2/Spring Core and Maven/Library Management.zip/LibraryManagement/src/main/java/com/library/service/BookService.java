package com.library.service;

import com.library.repository.BookRepository;

public class BookService {

    private BookRepository bookRepository;

    // Constructor Injection
    public BookService(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
        System.out.println("✅ Constructor Injection done!");
    }

    // Setter Injection
    public void setBookRepository(BookRepository bookRepository) {
        this.bookRepository = bookRepository;
        System.out.println("✅ Setter Injection done!");
    }

    public void addBook() {
        if (bookRepository != null) {
            bookRepository.saveBook();
        }
    }
}