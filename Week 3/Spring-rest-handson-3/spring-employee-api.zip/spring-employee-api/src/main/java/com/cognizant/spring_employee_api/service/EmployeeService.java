package com.cognizant.spring_employee_api.service;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Service;

import com.cognizant.spring_employee_api.model.Employee;

@Service
public class EmployeeService {

    public Employee getEmployee() {

        @SuppressWarnings("resource")
		ApplicationContext context =
                new ClassPathXmlApplicationContext("employee.xml");

        Employee emp = (Employee) context.getBean("employee");

        return emp;
    }
}