package com.cognizant.spring_employee_api.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.spring_employee_api.model.Employee;
import com.cognizant.spring_employee_api.service.EmployeeService;

@RestController
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @RequestMapping("/employee")
    public Employee getEmployee() {
        return employeeService.getEmployee();
    }
}