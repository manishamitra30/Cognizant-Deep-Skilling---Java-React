package com.cognizant.spring_learn;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class SpringLearnApplication {

    private static final Logger LOGGER =
            LoggerFactory.getLogger(SpringLearnApplication.class);

    public static void main(String[] args) {
        displayCountries();
    }

    public static void displayCountries() {

        LOGGER.info("START displayCountries");

        @SuppressWarnings("resource")
		ApplicationContext context =
                new ClassPathXmlApplicationContext("country.xml");

        // Get the list bean
        @SuppressWarnings("unchecked")
		List<Country> countryList =
                context.getBean("countryList", List.class);

        // Print all countries
        for (Country country : countryList) {
            LOGGER.debug("Country: {}", country);
        }

        LOGGER.info("END displayCountries");
    }
}