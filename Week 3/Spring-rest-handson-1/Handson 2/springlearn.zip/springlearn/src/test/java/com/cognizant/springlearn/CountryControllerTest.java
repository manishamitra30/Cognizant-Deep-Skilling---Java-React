package com.cognizant.springlearn;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.servlet.MockMvc;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
public class CountryControllerTest {

    @Autowired
    private MockMvc mockMvc;

    // ✅ Test 1: Valid Country - Check Status and Values
    @Test
    public void testGetCountry() throws Exception {
        mockMvc.perform(get("/country/IN"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").value("IN"))
                .andExpect(jsonPath("$.name").value("India"));
    }

    // ✅ Test 2: Check JSON Fields Exist
    @Test
    public void testJsonFieldExists() throws Exception {
        mockMvc.perform(get("/country/IN"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.code").exists())
                .andExpect(jsonPath("$.name").exists());
    }

    // ✅ Test 3: Invalid Country Code → Bad Request
    @Test
    public void testBadRequest() throws Exception {
        mockMvc.perform(get("/country/XYZ"))
                .andExpect(status().isBadRequest());
    }

    // ✅ Test 4: Bad Request with Reason Message
    @Test
    public void testBadRequestReason() throws Exception {
        mockMvc.perform(get("/country/XYZ"))
                .andExpect(status().isBadRequest())
                .andExpect(status().reason("Invalid country code"));
    }
}