package com.cognizant.employeemanagement.dao;

import com.cognizant.employeemanagement.exception.EmployeeNotFoundException;
import com.cognizant.employeemanagement.model.Employee;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;

@Repository
public class EmployeeDao {

    private static List<Employee> list = new ArrayList<>();

    public void updateEmployee(Employee employee) {
        boolean found = false;

        for (int i = 0; i < list.size(); i++) {
            if (list.get(i).getId().equals(employee.getId())) {
                list.set(i, employee);
                found = true;
                break;
            }
        }

        if (!found) {
            throw new EmployeeNotFoundException("Employee not found");
        }
    }

    public void deleteEmployee(int id) {
        boolean removed = list.removeIf(e -> e.getId() == id);

        if (!removed) {
            throw new EmployeeNotFoundException("Employee not found");
        }
    }
}