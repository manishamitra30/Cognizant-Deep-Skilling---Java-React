package com.cognizant.employeemanagement.service;

import com.cognizant.employeemanagement.model.*;

import org.springframework.stereotype.Service;

import java.util.Arrays;

@Service
public class EmployeeService {

    public Employee getEmployee() {

        Employee emp = new Employee();
        emp.setId(1);
        emp.setName("Manisha");
        emp.setSalary(50000.0);
        emp.setPermanent(true);

        Department dept = new Department();
        dept.setId(1);
        dept.setName("IT");

        Skill s1 = new Skill();
        s1.setId(1);
        s1.setName("Java");

        Skill s2 = new Skill();
        s2.setId(2);
        s2.setName("Spring Boot");

        emp.setDepartment(dept);
        emp.setSkillList(Arrays.asList(s1, s2));

        return emp;
    }

    public Employee addEmployee(Employee employee) {
        return employee;
    }
}