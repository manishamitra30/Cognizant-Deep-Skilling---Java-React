package com.cognizant.employeemanagement.controller;

import com.cognizant.employeemanagement.model.Country;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/countries")
public class CountryController {

    @PostMapping
    public Country addCountry(@RequestBody @Valid Country country) {
        System.out.println("Start");
        return country;
    }
}