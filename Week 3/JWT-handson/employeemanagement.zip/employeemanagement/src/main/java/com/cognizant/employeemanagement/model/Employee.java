package com.cognizant.employeemanagement.model;

public class Employee {

	public void setId(int i) {
		// TODO Auto-generated method stub
		
	}

	public void setName(String string) {
		// TODO Auto-generated method stub
		
	}

	public void setSalary(double d) {
		// TODO Auto-generated method stub
		
	}

	public void setPermanent1(boolean b) {
		// TODO Auto-generated method stub
		
	}

	public void setPermanent(boolean b) {
		// TODO Auto-generated method stub
		
	}

}
