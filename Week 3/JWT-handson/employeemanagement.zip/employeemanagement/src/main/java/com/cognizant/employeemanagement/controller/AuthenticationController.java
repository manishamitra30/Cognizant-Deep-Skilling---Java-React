package com.cognizant.employeemanagement.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class AuthenticationController {

    @GetMapping("/authenticate")
    public Map<String,String> authenticate(@RequestHeader("Authorization") String header) {

        Map<String,String> map = new HashMap<>();
        map.put("token","dummy-token");

        return map;
    }
}