package com.cognizant.employeemanagement.service;

import org.springframework.stereotype.Service;

import com.cognizant.employeemanagement.model.Employee;

@Service
public class EmployeeService {

    public Employee getEmployee() {
        Employee e = new Employee();
        e.setId(1);
        e.setName("Manisha");
        e.setSalary(50000.0);
        e.setPermanent(true);
        return e;
    }

    public Employee addEmployee(Employee e) {
        return e;
    }
}